/******************************************************************************
 * File: CheckSpacesServicesHelper.java
 * Copyright (c) 2023 Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
 *
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 *
 ******************************************************************************/

package com.qualcomm.snapdragon.spaces.helpers;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.util.Log;

import com.qualcomm.snapdragon.spaces.R;

public class CheckSpacesServicesHelper
{
    private static final String TAG = "Spaces-CheckSpacesServicesHelper";

    private Activity _callingActivity;

    private static final String _servicesPackageId = "com.qualcomm.qti.spaces.services";
    private static final String _openXrRuntimePackageId = "com.qualcomm.qti.openxrruntime";

    public CheckSpacesServicesHelper(Activity activity) {
        _callingActivity = activity;
    }

    public boolean CheckSpacesServicesInstalled() {
        boolean runtimeExists = false;

        // Check for Spaces Services runtime
        try {
            _callingActivity.getPackageManager().getPackageInfo(_servicesPackageId, 0);
            Log.v(TAG, "Spaces Services runtime was detected");
            runtimeExists = true;
        } catch (PackageManager.NameNotFoundException e) {
            Log.w(TAG, "Spaces Services runtime was NOT detected");
        }

        // Check for QXR Runtime
        if (!runtimeExists) {
            try {
                _callingActivity.getPackageManager().getPackageInfo(_openXrRuntimePackageId, 0);
                Log.v(TAG, "QXR runtime was detected");
                runtimeExists = true;
            } catch (PackageManager.NameNotFoundException e) {
                Log.w(TAG, "QXR runtime was NOT detected");
            }
        }

        if (!runtimeExists) {
            Log.v(TAG, "Spaces Services runtime is NOT installed");
            showAlertDialog(_callingActivity.getString(R.string.services_not_installed),
                    _callingActivity.getString(R.string.please_install_services),
                    _callingActivity.getString(R.string.install),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Uri appPageUri = Uri.parse("https://play.google.com/store/apps/details?id=" + _servicesPackageId);

                            Intent storeIntent = new Intent(Intent.ACTION_VIEW);
                            storeIntent.setData(appPageUri);
                            storeIntent.setPackage("com.android.vending");

                            try {
                                _callingActivity.startActivity(storeIntent);
                            } catch (ActivityNotFoundException anfe) {
                                // Google Play Store is not installed, so launch the URL in a browser
                                Intent webIntent = new Intent(Intent.ACTION_VIEW, appPageUri);
                                _callingActivity.startActivity(webIntent);
                            }

                            _callingActivity.finish();
                        }
                    },
                    _callingActivity.getString(R.string.quit),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            _callingActivity.finish();
                        }
                    },
                    false);
        }

        return runtimeExists;
    }

    private void showAlertDialog(String title, String message, String positiveButtonText, DialogInterface.OnClickListener positiveEvent, String negativeButtonText, DialogInterface.OnClickListener negativeEvent) {
        showAlertDialog(title, message, positiveButtonText, positiveEvent, negativeButtonText, negativeEvent, true);
    }

    private void showAlertDialog(String title, String message, String positiveButtonText, DialogInterface.OnClickListener positiveEvent, String negativeButtonText, DialogInterface.OnClickListener negativeEvent, boolean cancelable) {
        boolean darkMode = (_callingActivity.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES ? true : false;
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(_callingActivity,
            darkMode ? AlertDialog.THEME_DEVICE_DEFAULT_DARK : AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
        dialogBuilder.setTitle(title);
        dialogBuilder.setMessage(message);
        dialogBuilder.setPositiveButton(positiveButtonText, positiveEvent);
        dialogBuilder.setNegativeButton(negativeButtonText, negativeEvent);
        dialogBuilder.setCancelable(cancelable);
        dialogBuilder.show();
    }
}
